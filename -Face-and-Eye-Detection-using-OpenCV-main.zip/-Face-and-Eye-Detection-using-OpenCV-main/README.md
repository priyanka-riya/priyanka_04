# -Face-and-Eye-Detection-using-OpenCV
This project implements real-time face and eye detection using OpenCV's Haar Cascade classifiers. The system detects faces and eyes in a live video stream, highlights them with bounding boxes, and captures images every 2 seconds for storage.
